import { createFileRoute } from '@tanstack/react-router'
import { useState, useEffect, useRef } from 'react'

export const Route = createFileRoute('/')({
  component: HomePage,
})

function HomePage() {
  const [isScrolled, setIsScrolled] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const galleryRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50)
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const services = [
    { icon: '🚗', title: 'Driveway Cleaning', desc: 'Remove tough stains, oil marks, and grime from your concrete or paver driveway.' },
    { icon: '🏠', title: 'House Washing', desc: 'Gentle yet effective soft-wash exterior cleaning to eliminate algae, mildew, and buildup.' },
    { icon: '🚶', title: 'Sidewalk Cleaning', desc: 'Restore safe, clean walkways that enhance your property\'s safety and appearance.' },
    { icon: '🏡', title: 'Patio & Deck Cleaning', desc: 'Bring back the beauty of your outdoor living spaces with professional cleaning.' },
    { icon: '🛡️', title: 'Fence Cleaning', desc: 'Remove mold, algae, and weathering to extend your fence\'s lifespan and looks.' },
    { icon: '🏢', title: 'Commercial Pressure Washing', desc: 'Keep your business facade spotless and inviting for customers and clients.' },
  ]

  const trustBadges = [
    { icon: '✓', title: 'Reliable Service', desc: 'Consistently showing up on time, every time' },
    { icon: '✓', title: 'Affordable Pricing', desc: 'Competitive rates without sacrificing quality' },
    { icon: '✓', title: 'Attention to Detail', desc: 'Every corner and crack thoroughly cleaned' },
    { icon: '✓', title: 'Fast Response Times', desc: 'Quick quotes and even quicker service' },
    { icon: '✓', title: 'Satisfaction Focused', desc: 'We don\'t rest until you\'re 100% happy' },
    { icon: '✓', title: 'Locally Owned', desc: 'Proudly serving our community since day one' },
  ]

  const galleryImages = [
    { before: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=600&h=400&fit=crop', after: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=600&h=400&fit=crop', title: 'Driveway Restoration' },
    { before: 'https://images.unsplash.com/photo-1564013799919-ab600027ffc6?w=600&h=400&fit=crop', after: 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=600&h=400&fit=crop', title: 'House Exterior Wash' },
    { before: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=600&h=400&fit=crop', after: 'https://images.unsplash.com/photo-1600566753086-00f18fb6b3ea?w=600&h=400&fit=crop', title: 'Patio Deep Clean' },
    { before: 'https://images.unsplash.com/photo-1600585154526-990dced4db0d?w=600&h=400&fit=crop', after: 'https://images.unsplash.com/photo-1600573472556-e636c2acda88?w=600&h=400&fit=crop', title: 'Sidewalk Transformation' },
  ]

  const reviews = [
    { name: 'Michael R.', location: 'Oak Grove', rating: 5, text: 'Front Line Services transformed my filthy driveway into something that looks brand new. The before and after was absolutely dramatic. Fair price and professional crew.', date: '2 weeks ago' },
    { name: 'Sarah T.', location: 'Riverside', rating: 5, text: 'We hired them to clean our entire fence and back patio. They were punctual, thorough, and left zero mess behind. Our yard looks like we just moved in.', date: '1 month ago' },
    { name: 'James K.', location: 'Maple Heights', rating: 5, text: 'As a business owner, I needed our storefront pressure washed before a grand reopening. Front Line delivered same-day service and the place shines. Highly recommend!', date: '3 weeks ago' },
    { name: 'Linda M.', location: 'Cedar Park', rating: 5, text: 'I was skeptical about paying for pressure washing until I saw what they did for my home. The house washing removed years of grime. Worth every penny. These guys are the real deal.', date: '1 month ago' },
  ]

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    alert('Thank you for your inquiry! We\'ll be in touch within 24 hours.')
  }

  return (
    <div className="min-h-screen">
      {/* Navigation */}
      <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${isScrolled ? 'bg-matte-black/95 backdrop-blur-md shadow-lg' : 'bg-transparent'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            {/* Logo */}
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-emerald-deep rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-xl">FL</span>
              </div>
              <div>
                <span className="text-white font-bold text-xl tracking-tight">Front Line</span>
                <span className="text-emerald-deep font-bold text-xl"> Services</span>
              </div>
            </div>
            
            {/* Desktop Nav */}
            <div className="hidden md:flex items-center gap-8">
              <a href="#services" className="text-white/90 hover:text-emerald-deep transition-colors font-medium">Services</a>
              <a href="#gallery" className="text-white/90 hover:text-emerald-deep transition-colors font-medium">Gallery</a>
              <a href="#reviews" className="text-white/90 hover:text-emerald-deep transition-colors font-medium">Reviews</a>
              <a href="#quote" className="text-white/90 hover:text-emerald-deep transition-colors font-medium">Contact</a>
              <a href="tel:+15551234567" className="btn-primary text-sm py-3 px-6">
                <span>📞</span> (555) 123-4567
              </a>
            </div>

            {/* Mobile Menu Button */}
            <button 
              className="md:hidden text-white p-2"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                {mobileMenuOpen ? (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                ) : (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                )}
              </svg>
            </button>
          </div>

          {/* Mobile Menu */}
          {mobileMenuOpen && (
            <div className="md:hidden bg-matte-black/95 backdrop-blur-md pb-6">
              <div className="flex flex-col gap-4 pt-4">
                <a href="#services" onClick={() => setMobileMenuOpen(false)} className="text-white/90 hover:text-emerald-deep transition-colors font-medium px-4">Services</a>
                <a href="#gallery" onClick={() => setMobileMenuOpen(false)} className="text-white/90 hover:text-emerald-deep transition-colors font-medium px-4">Gallery</a>
                <a href="#reviews" onClick={() => setMobileMenuOpen(false)} className="text-white/90 hover:text-emerald-deep transition-colors font-medium px-4">Reviews</a>
                <a href="#quote" onClick={() => setMobileMenuOpen(false)} className="text-white/90 hover:text-emerald-deep transition-colors font-medium px-4">Contact</a>
                <a href="tel:+15551234567" className="btn-primary text-sm py-3 px-6 mx-4">
                  <span>📞</span> Call Now
                </a>
              </div>
            </div>
          )}
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center">
        <div className="absolute inset-0">
          <img 
            src="https://images.unsplash.com/photo-1621862731473-334db7fedbfc?w=1920&h=1080&fit=crop" 
            alt="Professional pressure washing" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-matte-black via-matte-black/80 to-matte-black/40" />
        </div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-32">
          <div className="max-w-2xl">
            <span className="inline-block bg-emerald-deep/90 text-white text-sm font-semibold px-4 py-2 rounded-full mb-6 animate-fade-in-up">
              ✨ Trusted by 500+ Local Homeowners
            </span>
            <h1 className="font-heading text-5xl md:text-6xl lg:text-7xl font-bold text-white mb-6 animate-fade-in-up delay-100">
              Restore Your Property's <span className="text-emerald-deep">Curb Appeal</span>
            </h1>
            <p className="text-xl md:text-2xl text-white/80 mb-10 leading-relaxed animate-fade-in-up delay-200">
              Professional pressure washing for driveways, houses, sidewalks, patios, fences, and commercial properties.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 animate-fade-in-up delay-300">
              <a href="#quote" className="btn-primary text-lg">
                Get a Free Quote
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                </svg>
              </a>
              <a href="tel:+15551234567" className="btn-outline border-white text-white hover:bg-white hover:text-matte-black text-lg">
                📞 Call Now
              </a>
            </div>
          </div>
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
          <svg className="w-6 h-6 text-white/60" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
          </svg>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="section-padding bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <span className="text-emerald-deep font-semibold text-sm uppercase tracking-wider">What We Do</span>
            <h2 className="section-title mt-3">Our Services</h2>
            <p className="section-subtitle mt-4">
              Professional grade equipment and expert techniques to transform any dirty surface.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <div 
                key={index}
                className="bg-white rounded-2xl p-8 shadow-lg card-hover border border-gray-100 group cursor-pointer"
              >
                <div className="w-16 h-16 bg-emerald-deep/10 rounded-2xl flex items-center justify-center mb-6 text-3xl group-hover:bg-emerald-deep group-hover:scale-110 transition-all duration-300">
                  {service.icon}
                </div>
                <h3 className="text-2xl font-bold text-matte-black mb-3">{service.title}</h3>
                <p className="text-gray-600 leading-relaxed">{service.desc}</p>
                <div className="mt-6 flex items-center gap-2 text-emerald-deep font-semibold group-hover:gap-3 transition-all duration-300">
                  Learn More
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="section-padding bg-matte-black text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <span className="text-emerald-deep font-semibold text-sm uppercase tracking-wider">Why Us</span>
            <h2 className="section-title mt-3 text-white">Why Choose Front Line Services</h2>
            <p className="section-subtitle mt-4 text-gray-400">
              We're not just another pressure washing company. Here's what sets us apart.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {trustBadges.map((badge, index) => (
              <div 
                key={index}
                className="bg-matte-dark rounded-2xl p-6 border border-gray-800 hover:border-emerald-deep/50 transition-all duration-300 group"
              >
                <div className="w-12 h-12 bg-emerald-deep/20 rounded-xl flex items-center justify-center mb-4 group-hover:bg-emerald-deep/30 transition-all duration-300">
                  <span className="text-emerald-deep text-xl">{badge.icon}</span>
                </div>
                <h3 className="text-xl font-bold text-white mb-2">{badge.title}</h3>
                <p className="text-gray-400 text-sm leading-relaxed">{badge.desc}</p>
              </div>
            ))}
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mt-20 pt-12 border-t border-gray-800">
            <div className="text-center">
              <div className="text-4xl md:text-5xl font-bold text-emerald-deep mb-2">500+</div>
              <div className="text-gray-400 text-sm uppercase tracking-wider">Homes Cleaned</div>
            </div>
            <div className="text-center">
              <div className="text-4xl md:text-5xl font-bold text-emerald-deep mb-2">8+</div>
              <div className="text-gray-400 text-sm uppercase tracking-wider">Years Experience</div>
            </div>
            <div className="text-center">
              <div className="text-4xl md:text-5xl font-bold text-emerald-deep mb-2">100%</div>
              <div className="text-gray-400 text-sm uppercase tracking-wider">Satisfaction</div>
            </div>
            <div className="text-center">
              <div className="text-4xl md:text-5xl font-bold text-emerald-deep mb-2">24hr</div>
              <div className="text-gray-400 text-sm uppercase tracking-wider">Response Time</div>
            </div>
          </div>
        </div>
      </section>

      {/* Before & After Gallery */}
      <section id="gallery" className="section-padding bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <span className="text-emerald-deep font-semibold text-sm uppercase tracking-wider">Results</span>
            <h2 className="section-title mt-3">Before & After Gallery</h2>
            <p className="section-subtitle mt-4">
              See the dramatic difference our professional cleaning makes.
            </p>
          </div>

          <div className="relative">
            <div 
              ref={galleryRef}
              className="gallery-slider flex gap-6 overflow-x-auto pb-8"
            >
              {galleryImages.map((image, index) => (
                <div 
                  key={index}
                  className="gallery-slide flex-shrink-0 w-full sm:w-[calc(50%-12px)] lg:w-[calc(33.333%-16px)]"
                >
                  <div className="bg-gray-100 rounded-2xl overflow-hidden">
                    <div className="grid grid-cols-2 gap-1">
                      <div className="relative">
                        <img src={image.before} alt={`${image.title} Before`} className="w-full h-48 sm:h-64 object-cover" />
                        <span className="absolute top-2 left-2 bg-red-500 text-white text-xs font-bold px-2 py-1 rounded">BEFORE</span>
                      </div>
                      <div className="relative">
                        <img src={image.after} alt={`${image.title} After`} className="w-full h-48 sm:h-64 object-cover" />
                        <span className="absolute top-2 right-2 bg-emerald-deep text-white text-xs font-bold px-2 py-1 rounded">AFTER</span>
                      </div>
                    </div>
                    <div className="p-4 bg-white">
                      <p className="font-semibold text-matte-black">{image.title}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Navigation Arrows */}
            <button 
              onClick={() => galleryRef.current?.scrollBy({ left: -300, behavior: 'smooth' })}
              className="absolute left-0 top-1/2 -translate-y-1/2 w-12 h-12 bg-white shadow-lg rounded-full flex items-center justify-center hover:bg-emerald-deep hover:text-white transition-all duration-300 z-10"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
              </svg>
            </button>
            <button 
              onClick={() => galleryRef.current?.scrollBy({ left: 300, behavior: 'smooth' })}
              className="absolute right-0 top-1/2 -translate-y-1/2 w-12 h-12 bg-white shadow-lg rounded-full flex items-center justify-center hover:bg-emerald-deep hover:text-white transition-all duration-300 z-10"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </button>
          </div>
        </div>
      </section>

      {/* Reviews Section */}
      <section id="reviews" className="section-padding bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <span className="text-emerald-deep font-semibold text-sm uppercase tracking-wider">Testimonials</span>
            <h2 className="section-title mt-3">What Our Customers Say</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {reviews.map((review, index) => (
              <div 
                key={index}
                className="bg-white rounded-2xl p-8 shadow-lg border border-gray-100"
              >
                <div className="flex items-center gap-1 mb-4">
                  {[...Array(review.rating)].map((_, i) => (
                    <svg key={i} className="w-5 h-5 text-yellow-400 fill-current" viewBox="0 0 20 20">
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                  ))}
                </div>
                <p className="text-gray-700 text-lg leading-relaxed mb-6 italic">"{review.text}"</p>
                <div className="flex items-center justify-between border-t border-gray-100 pt-4">
                  <div>
                    <p className="font-bold text-matte-black">{review.name}</p>
                    <p className="text-gray-500 text-sm">{review.location}</p>
                  </div>
                  <span className="text-gray-400 text-sm">{review.date}</span>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-12 text-center">
            <a href="#quote" className="btn-primary text-lg">
              Get Your Own Spotless Property
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
              </svg>
            </a>
          </div>
        </div>
      </section>

      {/* Quote Form */}
      <section id="quote" className="section-padding bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <span className="text-emerald-deep font-semibold text-sm uppercase tracking-wider">Free Estimate</span>
              <h2 className="section-title mt-3">Get Your Free Estimate Today</h2>
              <p className="text-gray-600 text-lg mt-4 leading-relaxed">
                Ready to restore your property's shine? Fill out the form and we'll get back to you within 24 hours with a no-obligation quote.
              </p>
              
              <div className="mt-10 space-y-6">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 bg-emerald-deep/10 rounded-xl flex items-center justify-center flex-shrink-0">
                    <span className="text-2xl">📍</span>
                  </div>
                  <div>
                    <p className="font-bold text-matte-black">Service Area</p>
                    <p className="text-gray-600">Oak Grove, Riverside, Maple Heights, Cedar Park, and surrounding counties</p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 bg-emerald-deep/10 rounded-xl flex items-center justify-center flex-shrink-0">
                    <span className="text-2xl">⏰</span>
                  </div>
                  <div>
                    <p className="font-bold text-matte-black">Quick Response</p>
                    <p className="text-gray-600">Most quotes delivered within 2-4 hours</p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 bg-emerald-deep/10 rounded-xl flex items-center justify-center flex-shrink-0">
                    <span className="text-2xl">✅</span>
                  </div>
                  <div>
                    <p className="font-bold text-matte-black">No Obligation</p>
                    <p className="text-gray-600">Free estimates with no pressure to commit</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-gray-50 rounded-3xl p-8 md:p-10 border border-gray-200">
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label className="block text-sm font-semibold text-matte-black mb-2">Your Name</label>
                  <input 
                    type="text" 
                    required
                    placeholder="John Smith"
                    className="w-full px-4 py-4 rounded-xl border border-gray-300 focus:border-emerald-deep focus:ring-2 focus:ring-emerald-deep/20 outline-none transition-all text-matte-black"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-matte-black mb-2">Phone Number</label>
                  <input 
                    type="tel" 
                    required
                    placeholder="(555) 123-4567"
                    className="w-full px-4 py-4 rounded-xl border border-gray-300 focus:border-emerald-deep focus:ring-2 focus:ring-emerald-deep/20 outline-none transition-all text-matte-black"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-matte-black mb-2">Address</label>
                  <input 
                    type="text" 
                    required
                    placeholder="123 Main Street, Your City"
                    className="w-full px-4 py-4 rounded-xl border border-gray-300 focus:border-emerald-deep focus:ring-2 focus:ring-emerald-deep/20 outline-none transition-all text-matte-black"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-matte-black mb-2">Service Needed</label>
                  <select 
                    required
                    className="w-full px-4 py-4 rounded-xl border border-gray-300 focus:border-emerald-deep focus:ring-2 focus:ring-emerald-deep/20 outline-none transition-all text-matte-black bg-white"
                  >
                    <option value="">Select a service...</option>
                    <option value="driveway">Driveway Cleaning</option>
                    <option value="house">House Washing</option>
                    <option value="sidewalk">Sidewalk Cleaning</option>
                    <option value="patio">Patio & Deck Cleaning</option>
                    <option value="fence">Fence Cleaning</option>
                    <option value="commercial">Commercial Pressure Washing</option>
                    <option value="other">Other / Multiple Services</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-semibold text-matte-black mb-2">Message (Optional)</label>
                  <textarea 
                    rows={4}
                    placeholder="Tell us about your project..."
                    className="w-full px-4 py-4 rounded-xl border border-gray-300 focus:border-emerald-deep focus:ring-2 focus:ring-emerald-deep/20 outline-none transition-all resize-none text-matte-black"
                  />
                </div>
                <button type="submit" className="w-full btn-primary justify-center text-lg">
                  Get Your Free Estimate Today
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </button>
                <p className="text-center text-gray-500 text-sm">
                  Or call directly: <a href="tel:+15551234567" className="text-emerald-deep font-semibold">(555) 123-4567</a>
                </p>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-matte-black text-white pt-20 pb-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
            <div className="lg:col-span-2">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 bg-emerald-deep rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-xl">FL</span>
                </div>
                <div>
                  <span className="text-white font-bold text-xl tracking-tight">Front Line</span>
                  <span className="text-emerald-deep font-bold text-xl"> Services</span>
                </div>
              </div>
              <p className="text-gray-400 leading-relaxed mb-6 max-w-md">
                Professional pressure washing services that restore and protect your property. We bring years of experience, top-tier equipment, and a commitment to excellence to every job.
              </p>
              <div className="flex gap-4">
                <a href="#" className="w-10 h-10 bg-gray-800 hover:bg-emerald-deep rounded-lg flex items-center justify-center transition-colors">
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M24 4.557c-.883.392-1.832.656-2.828.775 1.017-.609 1.798-1.574 2.165-2.724-.951.564-2.005.974-3.127 1.195-.897-.957-2.178-1.555-3.594-1.555-3.179 0-5.515 2.966-4.797 6.045-4.091-.205-7.719-2.165-10.148-5.144-1.29 2.213-.669 5.108 1.523 6.574-.806-.026-1.566-.247-2.229-.616-.054 2.281 1.581 4.415 3.949 4.89-.693.188-1.452.232-2.224.084.626 1.956 2.444 3.379 4.6 3.419-2.07 1.623-4.678 2.348-7.29 2.04 2.179 1.397 4.768 2.212 7.548 2.18 9.142 0 14.307-7.721 13.995-14.646.962-.695 1.797-1.562 2.457-2.549z"/></svg>
                </a>
                <a href="#" className="w-10 h-10 bg-gray-800 hover:bg-emerald-deep rounded-lg flex items-center justify-center transition-colors">
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/></svg>
                </a>
                <a href="#" className="w-10 h-10 bg-gray-800 hover:bg-emerald-deep rounded-lg flex items-center justify-center transition-colors">
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M22.675 0h-21.35c-.732 0-1.325.593-1.325 1.325v21.351c0 .731.593 1.324 1.325 1.324h11.35v-9.294h-3.128v-3.622h3.128v-2.671c0-3.1 1.893-4.788 4.659-4.788 1.325 0 2.463.099 2.795.143v3.24l-1.918.001c-1.504 0-1.795.715-1.795 1.763v2.313h3.587l-.467 3.622h-3.12v9.293h6.116c.73 0 1.323-.593 1.323-1.325v-21.35c0-.732-.593-1.325-1.325-1.325z"/></svg>
                </a>
                <a href="#" className="w-10 h-10 bg-gray-800 hover:bg-emerald-deep rounded-lg flex items-center justify-center transition-colors">
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M19.615 3.184c-3.604-.246-11.631-.245-15.23 0-3.897.266-4.356 2.62-4.385 8.816.029 6.185.484 8.549 4.385 8.816 3.6.245 11.626.246 15.23 0 3.897-.266 4.356-2.62 4.385-8.816-.029-6.185-.484-8.549-4.385-8.816zm-10.615 12.816v-8l8 3.993-8 4.007z"/></svg>
                </a>
              </div>
            </div>

            <div>
              <h3 className="font-bold text-lg mb-6">Quick Links</h3>
              <ul className="space-y-4">
                <li><a href="#services" className="text-gray-400 hover:text-emerald-deep transition-colors">Services</a></li>
                <li><a href="#gallery" className="text-gray-400 hover:text-emerald-deep transition-colors">Gallery</a></li>
                <li><a href="#reviews" className="text-gray-400 hover:text-emerald-deep transition-colors">Reviews</a></li>
                <li><a href="#quote" className="text-gray-400 hover:text-emerald-deep transition-colors">Get a Quote</a></li>
              </ul>
            </div>

            <div>
              <h3 className="font-bold text-lg mb-6">Contact Us</h3>
              <ul className="space-y-4">
                <li className="flex items-center gap-3 text-gray-400">
                  <span>📞</span>
                  <a href="tel:+15551234567" className="hover:text-emerald-deep transition-colors">(555) 123-4567</a>
                </li>
                <li className="flex items-center gap-3 text-gray-400">
                  <span>✉️</span>
                  <a href="mailto:info@frontlineservices.com" className="hover:text-emerald-deep transition-colors">info@frontlineservices.com</a>
                </li>
                <li className="flex items-start gap-3 text-gray-400">
                  <span>📍</span>
                  <span>Serving Oak Grove, Riverside, Maple Heights, Cedar Park & surrounding areas</span>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-gray-500 text-sm">
              © {new Date().getFullYear()} Front Line Services. All rights reserved.
            </p>
            <p className="text-gray-500 text-sm">
              Made with ❤️ in the Local Community
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}